fn main() {
    let x = 3;
    let y = 5;
}
