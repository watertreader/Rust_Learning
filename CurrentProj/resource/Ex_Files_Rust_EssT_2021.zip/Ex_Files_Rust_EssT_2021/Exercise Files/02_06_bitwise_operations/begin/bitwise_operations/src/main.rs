fn main() {
    let value = 0b11110101;
    println!("value is {}", value);
}