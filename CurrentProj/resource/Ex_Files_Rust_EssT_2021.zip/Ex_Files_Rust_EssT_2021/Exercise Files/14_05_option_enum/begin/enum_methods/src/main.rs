fn main() {
    let countdown = [5, 4, 3, 2, 1];
    let number = countdown[5];
    println!("number is {:?}", number);
}