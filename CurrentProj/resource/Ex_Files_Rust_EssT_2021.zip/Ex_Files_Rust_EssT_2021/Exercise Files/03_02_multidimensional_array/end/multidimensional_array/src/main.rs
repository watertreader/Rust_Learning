fn main() {
    let parking_lot = [[1, 2, 3],
                       [4, 5, 6]];

    let number = parking_lot[1][2];
    println!("number is {}", number);
    
    let garage = [[[0; 10]; 10]; 100];
}
