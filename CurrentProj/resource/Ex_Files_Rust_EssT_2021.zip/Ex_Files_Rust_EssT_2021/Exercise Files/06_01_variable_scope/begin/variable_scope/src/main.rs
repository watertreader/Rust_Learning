fn main() {
    let planet = "Earth";
    println!("planet is {}", planet);
}
