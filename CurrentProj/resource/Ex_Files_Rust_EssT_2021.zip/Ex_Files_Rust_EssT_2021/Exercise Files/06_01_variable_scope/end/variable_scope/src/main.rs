fn main() {
    let planet = "Earth";
    if true {   
        println!("planet is {}", planet);
    }
    println!("planet is {}", planet);
}