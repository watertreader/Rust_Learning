fn main() {
    let number = Some(13);

    match number {
        Some(13) => println!("thirteen"),
        _ => ()
    }    
}
