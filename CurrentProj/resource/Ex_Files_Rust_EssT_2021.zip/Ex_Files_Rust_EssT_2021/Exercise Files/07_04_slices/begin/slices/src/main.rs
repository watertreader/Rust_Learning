fn main() {
    let message = String::from("Greetings from Earth!");
    println!("message is {}", message);
}