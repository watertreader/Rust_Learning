// my hello world program
fn main() {
    /* multiple
       line
       comment */
    println!("Hello, world!");
}
