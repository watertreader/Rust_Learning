fn main() {
    let message = ['h', 'e', 'l', 'l', 'o'];
}
