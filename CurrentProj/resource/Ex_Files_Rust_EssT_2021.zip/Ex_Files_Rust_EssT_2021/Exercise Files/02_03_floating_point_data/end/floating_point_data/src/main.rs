fn main() {
    let x: f32 = 10.123456789123456789;
    println!("x is {}", x);
}