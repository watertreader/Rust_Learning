fn main() {
    let x = 10;
    println!("x is {}", x);
}