fn main() {
    let x = 3;
}
