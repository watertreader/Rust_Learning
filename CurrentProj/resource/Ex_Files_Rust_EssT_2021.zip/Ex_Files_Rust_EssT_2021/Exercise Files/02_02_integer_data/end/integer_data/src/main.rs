fn main() {
    let mut x: u8 = 255;
    x = x + 1;
    println!("x is {}", x);
}