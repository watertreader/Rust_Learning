fn main() {
    let a = 10;
    let b = 3;
    let c = a + b;
    println!("c is {}", c);
}
