fn main() {
    let mut message = String::from("Earth");
    println!("message is {}", message);
    message.push_str(" is home.");
    println!("message is {}", message);
}