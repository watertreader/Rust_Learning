fn main() {
    let letter = 'a';
    let number = '1';
}
