fn main() {
    let a = 10.0;
    let b = 3.0;
    let c = a / b;
    println!("c is {}", c);
}